// Place file at: src/app/auth/login.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email = 'admin@example.com';
  password = 'adminpassword';
  remember = true;
  error: string | null = null;
  loading = false;

  constructor(private auth: AuthService, private router: Router) {}

  submit() {
    this.error = null;
    this.loading = true;
    this.auth.login(this.email, this.password, this.remember).subscribe({
      next: (user) => {
        this.loading = false;
        if (user.role === 'admin') this.router.navigate(['/admin']);
        else if (user.role === 'retailer') this.router.navigate(['/retailer']);
        else if (user.role === 'customer') this.router.navigate(['/dashboard']);
        else this.router.navigate(['/']);
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error?.message || 'Login failed. Check credentials.';
      }
    });
  }
}
