// Place file at: src/app/auth/role.guard.ts
import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const allowedRoles: string[] = route.data['roles'] || [];
    const user = this.auth.getUser();

    if (!user || !user.token) {
      // not logged in
      this.router.navigate(['/']);
      return false;
    }

    if (allowedRoles.length === 0) {
      // any logged-in user allowed
      return true;
    }

    if (user.role && allowedRoles.includes(user.role)) {
      return true;
    }

    // logged in but wrong role -> navigate to role default
    const target = this.getDefaultRouteForRole(user.role);
    this.router.navigate([target]);
    return false;
  }

  private getDefaultRouteForRole(role: string | null) {
    switch (role) {
      case 'admin': return '/admin';
      case 'retailer': return '/retailer';
      case 'customer': return '/dashboard';
      default: return '/';
    }
  }
}
