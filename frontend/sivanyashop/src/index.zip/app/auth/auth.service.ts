// Place file at: src/app/auth/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { AppConfig } from '../app.config';

export type Role = 'customer' | 'retailer' | 'admin' | null;

export interface UserPayload {
  id?: string;
  name?: string;
  role: Role;
  token?: string;
  // include any other fields your backend returns
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private storageKey = 'user';
  private apiBase = AppConfig.apiBase;

  constructor(private http: HttpClient) {}

  login(email: string, password: string, remember = true): Observable<UserPayload> {
    return this.http.post<any>(`${this.apiBase}/api/auth/login`, { email, password }).pipe(
      map(res => {
        // adapt mapping if your backend uses different field names
        const user: UserPayload = {
          id: res.id ?? res.userId,
          name: res.name ?? res.username,
          role: (res.role as Role) ?? null,
          token: res.token ?? res.accessToken ?? res.jwt
        };
        this.setUser(user, !remember);
        return user;
      })
    );
  }

  setUser(user: UserPayload, useSession = false) {
    const serialized = JSON.stringify(user);
    if (useSession) sessionStorage.setItem(this.storageKey, serialized);
    else localStorage.setItem(this.storageKey, serialized);
  }

  getUser(): UserPayload | null {
    const raw = localStorage.getItem(this.storageKey) ?? sessionStorage.getItem(this.storageKey);
    if (!raw) return null;
    try { return JSON.parse(raw) as UserPayload; }
    catch { return null; }
  }

  getToken(): string | null {
    return this.getUser()?.token ?? null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getRole(): Role {
    return this.getUser()?.role ?? null;
  }

  clear() {
    localStorage.removeItem(this.storageKey);
    sessionStorage.removeItem(this.storageKey);
  }

  logout() {
    this.clear();
  }
}
