// PLACE IN: src/app/auth/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { AppConfig } from '../app.config';

// 👇 Add this interface
export interface UserPayload {
  email?: string;
  role: 'ADMIN' | 'RETAILER' | 'CUSTOMER';
  name?: string;
  [key: string]: any;
}

export interface LoginResp {
  token: string;
  role: UserPayload['role'];
  user?: UserPayload;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private tokenKey = 'sivanya_token';
  private roleKey = 'sivanya_role';
  private userKey = 'sivanya_user';

  private _token$ = new BehaviorSubject<string | null>(localStorage.getItem(this.tokenKey));
  token$ = this._token$.asObservable();

  private _role$ = new BehaviorSubject<string | null>(localStorage.getItem(this.roleKey));
  role$ = this._role$.asObservable();

  private apiRoot = AppConfig.apiBase.replace(/\/+$/, '');

  constructor(private http: HttpClient, private router: Router) {}

  private url(path: string) {
    return `${this.apiRoot}/${path.replace(/^\/+/, '')}`;
  }

  // ---- AUTH API CALLS ----

  login(email: string, password: string): Observable<LoginResp> {
    return this.http.post<LoginResp>(this.url('api/auth/login'), { email, password }).pipe(
      tap((resp) => {
        localStorage.setItem(this.tokenKey, resp.token);
        localStorage.setItem(this.roleKey, resp.role);
        if (resp.user) {
          localStorage.setItem(this.userKey, JSON.stringify(resp.user));
        }
        this._token$.next(resp.token);
        this._role$.next(resp.role);
      })
    );
  }

  registerCustomer(payload: { name: string; email: string; password: string }) {
    return this.http.post<any>(this.url('api/auth/register'), payload);
  }

  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.roleKey);
    localStorage.removeItem(this.userKey);
    this._token$.next(null);
    this._role$.next(null);
    this.router.navigate(['/login']);
  }

  // ---- HELPERS ----

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  getRole(): UserPayload['role'] | null {
    return (localStorage.getItem(this.roleKey) as UserPayload['role']) || null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  // 👇 Add this helper for CustomerDashboardComponent
  getUser(): UserPayload | null {
    const json = localStorage.getItem(this.userKey);
    if (json) {
      try {
        return JSON.parse(json);
      } catch {
        return null;
      }
    }
    return null;
  }

  // (Optional) If you want to fetch user from API
  fetchUserFromServer(): Observable<UserPayload> {
    return this.http.get<UserPayload>(this.url('api/auth/me'));
  }
}
