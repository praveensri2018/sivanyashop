// PLACE IN: src/app/services/admin-product.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfig } from '../app.config';

/**
 * Product shape used by shop components.
 * Extend this to match the real fields returned by your backend.
 */
export interface Product {
  id: number | string;
  name: string;
  description?: string;
  imagePath?: string;
  categoryIds?: number[];
  // optional variant/price/stock fields can be added here
  [key: string]: any;
}

@Injectable({ providedIn: 'root' })
export class AdminProductService {
  private apiRoot = AppConfig.apiBase.replace(/\/+$/, '');

  constructor(private http: HttpClient) {}

  private url(path: string) {
    return `${this.apiRoot}/${path.replace(/^\/+/, '')}`;
  }

  // === Methods your shop components expect ===

  /**
   * Fetch paginated products.
   * Returns whatever the backend returns (array or { items, total }).
   * Usage: fetchProducts(page, limit).subscribe(...)
   */
  fetchProducts(page = 1, limit = 12): Observable<any> {
    const q = `page=${encodeURIComponent(page)}&limit=${encodeURIComponent(limit)}`;
    return this.http.get(this.url(`api/products?${q}`));
  }

  /**
   * Fetch single product by id.
   * Usage: fetchProduct(id).subscribe(...)
   */
  fetchProduct(id: string | number): Observable<Product> {
    return this.http.get<Product>(this.url(`api/products/${id}`));
  }

  // === Other admin methods you had earlier ===

  createCategory(payload: { name: string; parentCategoryId: number | null }): Observable<any> {
    return this.http.post(this.url('api/products/category'), payload);
  }

  createProduct(payload: any): Observable<any> {
    return this.http.post(this.url('api/products/product'), payload);
  }

  addVariant(payload: any): Observable<any> {
    return this.http.post(this.url('api/products/variant'), payload);
  }

  setVariantPrice(payload: any): Observable<any> {
    return this.http.post(this.url('api/products/variant/price'), payload);
  }

  uploadProductImages(formData: FormData): Observable<any> {
    return this.http.post(this.url('api/product-images/upload'), formData);
  }

  getProductsPaginated(page = 1, limit = 10): Observable<any> {
    return this.http.get(this.url(`api/products?page=${page}&limit=${limit}`));
  }

  updateProduct(id: number | string, payload: any) {
    return this.http.put(this.url(`api/products/product/${id}`), payload);
  }

  deleteProduct(id: number | string) {
    return this.http.delete(this.url(`api/products/${id}`));
  }
}
